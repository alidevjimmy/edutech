<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/css/font.css')); ?>">

        <title>فرم</title>
        <style>
            body,html{
                padding: 0;
                margin: 0;
            }
        </style>
    </head>
    <body style="background-color: #160031;font-family: 'IRANSans' !important" dir="rtl">
        <div id="app"></div>
        <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/jimmy/Codes/Projects/edutech/resources/views/app.blade.php ENDPATH**/ ?>