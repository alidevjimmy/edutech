import React, {useState} from 'react'
import {KeyboardArrowUp, KeyboardArrowDown, Place, Phone, Close} from "@material-ui/icons";
import {IconButton} from '@material-ui/core'
import {makeStyles} from '@material-ui/core'
import {Container, Col, Row} from 'react-bootstrap'

const useStyles = makeStyles(theme => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        height: 140,
        width: 100,
    },
    control: {
        padding: theme.spacing(2),
    },
}));

const Footer = () => {
    const [open, setOpen] = useState(false)
    const classes = useStyles();
    return (
        <>
            <div style={{width: '100%', height: 'auto', textAlign: 'center', position: 'absolute', bottom: '0px'}}>
                {!open ? <>
                    <IconButton onClick={() => setOpen(!open)}>
                        <KeyboardArrowUp style={{color: 'white', fontSize: '62px'}}/>
                    </IconButton>
                </> : <>
                    <IconButton onClick={() => setOpen(!open)}>
                        <KeyboardArrowDown style={{color: 'white', fontSize: '62px'}}/>
                    </IconButton>
                </>}
            </div>
            <div className={`${open ? 'footer' : null}`} style={open ? {
                backgroundColor: '#281047',
                width: '100%',
                height: 'auto',
                position: 'absolute',
                bottom: '0',
                transition: '1s all',
                paddingBottom: '36px',
            } : {
                backgroundColor: '#281047',
                width: '100%',
                height: 'auto',
                position: 'absolute',
                bottom: '-100%',
                transition: '1s all',
                paddingBottom: '36px',
                display: 'none'
            }}>
                <Container style={{ textAlign : 'right' }}>
                    {open ? <>
                        <br/>
                        <IconButton style={{color: 'white'}} color='inherit' onClick={() => setOpen(!open)}>
                            <Close className={'cancleFooter'}/>
                        </IconButton></> : null}
                </Container>
                <Container style={{color: 'white', textAlign: 'right', display: 'flex'}}>
                    <div style={{width: '50%'}} className={'col'}>
                        <br/>
                        <Place/>
                        <span>    </span>
                        <span>
                        همدان، خیابان طالقانی خیابان فرهنگ، مرکز رشد دانشگاه بوعلی
                    </span>
                        <br/>
                        <br/>
                        <Phone/>
                        <span>    </span>
                        <span>
                        081-38267981
                    </span>
                    </div>
                    <div style={{width: '50%'}} className={'col'}>
                        <br/>
                        <a href="http://khishavere.com"><img src="/images/3f24f4a8-6d10-4eab-8794-e5fcf6a5ab5f.jpg" width='150' alt='خیشاوره'/></a>
                        <a href="http://roshd.basu.ac.ir/"><img src="/images/fe65e9ef-7393-489e-9a13-5bff73cfe4b2.jpg" width='150' alt='http://roshd.basu.ac.ir/'/></a>
                        <a href="http://www.edutech.co/"><img src="/images/0d596c72-4fd2-4f31-ab99-fa755e510205.jpg" width='150' alt='اجوتک'/></a>
                    </div>
                </Container>
            </div>
        </>
    )
}

export default Footer
